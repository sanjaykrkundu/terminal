
$themeMap = @{
    "$home"           = "blue-owl.json"
    "$home\Documents" = "work.json"
    "C:\Windows"      = "admin.json"
    "default"         = "aliens.json" # Fallback theme
}

# $themeFolder = Join-Path -Path (Split-Path $PROFILE) -ChildPath "themes"
$themeFolder = Join-Path -Path (Split-Path $PROFILE) -ChildPath "sanjaytheme"
$themeName = "aliens.json"
$terminalTheme = "Ubuntu-22.04-ColorScheme"
$terminalTheme = "Campbell PowerShell"

$loadFromCache = $true
$global:iscached = $false

$terminalColors = [PSCustomObject]@{
    "default"                  = @{
        foreground = "#FFFFFF"
        background = "#000000"
    }
    "Campbell"                 = @{
        background = "#0C0C0C"
        foreground = "#CCCCCC"
    }
    "CGA"                      = @{
        background = "#000000"
        foreground = "#AAAAAA"
    }
    "Campbell PowerShell"      = @{
        background = "#012456"
        foreground = "#CCCCCC"
    }
    "Aurora"                   = @{
        background = "#23262E"
        foreground = "#FFCA28"
    }
    "Blue Matrix"              = @{
        background = "#101116"
        foreground = "#00A2FF"
    }
    "Catppuccin Mocha"         = @{
        background = "#1E1E2E"
        foreground = "#CDD6F4"
    }
    "Color Scheme 15"          = @{
        background = "#000000"
        foreground = "#FFFFFF"
    }
    "Color Scheme 16"          = @{
        background = "#8962BB"
        foreground = "#FFFFFF"
    }
    "Color Scheme 17"          = @{
        background = "#000000"
        foreground = "#FFFFFF"
    }
    "CyberPunk2077"            = @{
        background = "#272932"
        foreground = "#E455AE"
    }
    "Dark+"                    = @{
        background = "#1E1E1E"
        foreground = "#CCCCCC"
    }
    "Dimidium"                 = @{
        background = "#141414"
        foreground = "#BAB7B6"
    }
    "Dracula"                  = @{
        background = "#1E1E1E"
        foreground = "#FFFFFF"
    }
    "IBM 5153"                 = @{
        background = "#000000"
        foreground = "#AAAAAA"
    }
    "One Half Dark"            = @{
        background = "#282c34"
        foreground = "#DCDFE4"
    }
    "One Half Light"           = @{
        background = "#FAFAFA"
        foreground = "#383A42"
    }
    "Ottosson"                 = @{
        background = "#000000"
        foreground = "#BEBEBE"
    }
    "Proxmox"                  = @{
        background = "#BA6D00"
        foreground = "#FFFFFF"
    }
    "Red Sands"                = @{
        background = "#3F0000"
        foreground = "#D7C9A7"
    }
    "Solarized Dark"           = @{
        background = "#002B36"
        foreground = "#839496"
    }
    "Solarized Light"          = @{
        background = "#FDF6E3"
        foreground = "#657B83"
    }
    "Tang Dark"                = @{
        background = "#000000"
        foreground = "#D3D7CF"
    }
    "Tang Light"               = @{
        background = "#FFFFFF"
        foreground = "#555753"
    }
    "Ubuntu"                   = @{
        background = "#300A24"
        foreground = "#EEEEEC"
    }
    "Ubuntu-22.04-ColorScheme" = @{
        background = "#300A24"
        foreground = "#FFFFFF"
    }
    "Vintage"                  = @{
        background = "#000000"
        foreground = "#C0C0C0"
    }
    "ayu"                      = @{
        background = "#0F1419"
        foreground = "#E6E1CF"
    }
}

if ($terminalColors.$terminalTheme) {
    $terminal = $terminalColors.$terminalTheme
}
else {
    $terminal = $terminalColors.default
}

function Initialize-Theme {
    $currentPath = $PWD.Path
    if ($themeMap[$currentPath]) {
        $themeName = $themeMap[$currentPath]
    }
    $themeFile = Join-Path -Path $themeFolder -ChildPath $themeName
    $cacheFile = $themeFile + ".cache"
    if (!$global:theme -or $global:theme.themeName -ne $themeName) {
        if (Test-Path $themeFile) {
            # Write-Host "from disk"
            $global:theme = Get-Content -Raw $themeFile | ConvertFrom-Json
            $global:theme | Add-Member -MemberType NoteProperty -Name "themeName" -Value $themeName -Force
            $cacheFile = $themeFile + ".cache"
            $global:iscached = $false
            if (Test-Path $cacheFile) { Remove-Item $cacheFile }
        }  else {
            Write-Warning "Theme file not found at $themeFile"
        }
    } elseif (!$global:iscached -and ($loadFromCache -eq $true)) {
        # Write-Host "from cache file"
        $global:theme = Get-Content -Raw $cacheFile | ConvertFrom-Json
        $global:iscached = $true
    }

    Render-Theme $global:theme $global:iscached
}

function Show-CachedPrompt {
    param($theme)

    $line = @{
        "left"  = @{
            "output" = ""
        }
        "right" = @{
            "output" = ""
        }
    }
    foreach ($block in $theme.blocks) {
        if ($line[$block.alignment].output.Length -gt 0) {
            Dump-Line $line $false
        }
        $line[$block.alignment].output = $block.output
    }
    if ($line["left"].output.Length -gt 0 -or $line["right"].output.Length -gt 0 ) {
        Dump-Line $line $true
    }

}


function Render-Theme {
    param ($theme, $iscached = $false)

    $line = @{
        "left"  = @{
            "output" = ""
        }
        "right" = @{
            "output" = ""
        }
    }

    $cacheBlocks = @()

    if ($iscached -and ($loadFromCache -eq $true)) {
        Show-CachedPrompt $theme
        return
    }

    for ($i = 0; $i -lt $theme.blocks.Count; $i++) {
        $block = $theme.blocks[$i]
        $alignment = $block.alignment ? $block.alignment : "left"

        $output = Render-Block $block
        $output = Render-Static-Values $output

        $cacheBlocks += [PSCustomObject]@{
            alignment = $alignment
            output    = $output
        }

        if ($line[$alignment].output.Length -gt 0) {
            Dump-Line $line $false
        }

        $line[$alignment].output = $output
    }

    if ($line["left"].output.Length -gt 0 -or $line["right"].output.Length -gt 0 ) {
        Dump-Line $line $true
    }

    if ($null -ne $loadFromCache -and $loadFromCache -eq $true) {
        $cache = [PSCustomObject]@{
            themeName = $global:theme.themeName
            blocks = $cacheBlocks
        }
        $cache | ConvertTo-Json | Out-File -FilePath $cacheFile -Encoding utf8
        # Write-Host "Cache is stored at: $cacheFile" -NoNewline
    }
}

function Dump-Line {
    param ($line, $isLast)

    # 1. Render Left
    $_renderedLeft = Render-Dynamic-Values $line.left.output
    Write-Host $_renderedLeft -NoNewline

    # 2. Render Right
    if ($line.right.output) {
        $columns = $Host.UI.RawUI.WindowSize.Width
        $_renderedRight = Render-Dynamic-Values $line.right.output

        # This regex removes all ESC[...m sequences so we only count visible letters
        $visibleText = $_renderedRight -replace "\e\[[0-9;]*[mGKHJKfP]" -replace "`e\[[0-9;]*[mGKHJKfP]"
        $rightLen = $visibleText.Length

        # Calculate exact start position
        $cursorPos = $columns - $rightLen + 1 

        # Move cursor and print
        Write-Host "$([char]27)[$($cursorPos)G$($_renderedRight)" -NoNewline
    }

    # 3. Handle Last Line Cursor Position
    if ($isLast) {
        # Move cursor back to the end of the LEFT text so the user can type there
        $visibleLeft = $_renderedLeft -replace "\e\[[0-9;]*[mGKHJKfP]" -replace "`e\[[0-9;]*[mGKHJKfP]"
        $leftLen = $visibleLeft.Length + 1
        Write-Host "$([char]27)[$($leftLen)G" -NoNewline
    }
    else {
        Write-Host "" # Move to next line if not the last
    }

    # Clear objects to prevent ghosting
    $line.left = @{}
    $line.right = @{}
}

function Render-Block {
    param ($block)

    $output = ""
    for ($i = 0; $i -lt $block.segments.Count; $i++) {
        $segment = $block.segments[$i]
        $preSegment = @{}
        $nextSegment = @{}
        $isInvertedStart = $false
        $isInvertedEnd = $false
        $isLast = $false
        $isFirst = $false

        $startSymbolBg = HexToRBG $terminal.background -Background $true
        $startSymbolFg = HexToRBG $terminal.foreground
        $endSymbolBg = $startSymbolBg
        $endSymbolFg = $startSymbolBg


        if ($i -gt 0) {
            $preSegment = $block.segments[($i - 1)]
        }
        else {
            $isFirst = $true
        }
        if ($i -lt $block.segments.Count - 1) {
            $nextSegment = $block.segments[($i + 1)]
        }
        else {
            $isLast = $true
        }

        $startSymbol = ""
        $endSymbol = ""

        if ($segment.symbols.inverted_leading) {
            $startSymbol = $segment.symbols.inverted_leading
            $isInvertedStart = $true
        }
        elseif ($segment.symbols.leading) {
            $startSymbol = $segment.symbols.leading
        }
        if ($segment.symbols.inverted_trailing) {
            $endSymbol = $segment.symbols.inverted_trailing
            $isInvertedEnd = $true
        }
        elseif ($segment.symbols.trailing) {
            $endSymbol = $segment.symbols.trailing
        }

        if ($segment.background) {
            $segBg = HexToRBG $segment.background -Background $true
            if ($isInvertedStart -eq $false) {
                $startSymbolFg = HexToRBG $segment.background
            }
            else {
                $startSymbolBg = HexToRBG $segment.background -Background $true
            }
            if ($isInvertedEnd -eq $false) {
                $endSymbolFg = HexToRBG $segment.background
            }
        }
        else {
            $segBg = HexToRBG $terminal.background -Background $true
        }

        if ($segment.foreground) {
            $segFg = HexToRBG $segment.foreground
        }
        else {
            $segFg = HexToRBG $terminal.foreground 
        }

        if ($preSegment.background) {
            if ($isInvertedStart -eq $false -and !$preSegment.symbols.inverted_trailing) {
                $startSymbolBg = HexToRBG $preSegment.background -Background $true
            }
        }
        else {
            if ($isInvertedStart -eq $false) {
                $startSymbolBg = HexToRBG $terminal.background -Background $true
            }
        }

        if ($nextSegment.background -and !$nextSegment.symbols.inverted_leading -and !$isInvertedEnd) {
            $endSymbolBg = HexToRBG $nextSegment.background -Background $true
        }
        elseif ($isInvertedEnd -and $segment.background) {
            $endSymbolBg = HexToRBG $segment.background -Background $true
        }
        else {
            $endSymbolBg = HexToRBG $terminal.background -Background $true
        }

        if ($isInvertedStart) {
            $startSymbolFg = HexToRBG $terminal.background
        }
        if ($isInvertedEnd) {
            $endSymbolFg = HexToRBG $terminal.background
        }

        if ($isFirst -and $isInvertedStart -eq $false) {
            # Write-Host $startSymbolFg$startSymbol$($PSStyle.Reset) -NoNewline
            $output += "$startSymbolFg$startSymbol$($PSStyle.Reset)"
        }
        else {
            # Write-Host $startSymbolBg$startSymbolFg$startSymbol$($PSStyle.Reset) -NoNewline
            $output += "$startSymbolBg$startSymbolFg$startSymbol$($PSStyle.Reset)"
        }
        $_template = Render-Intermediate-Tags $segment.template $segBg $segFg
        # Write-Host $segBg$segFg$($segment.template)$($PSStyle.Reset) -NoNewline
        # $output += "$segBg$segFg$($segment.template)$($PSStyle.Reset)"
        $output += "$segBg$segFg$_template$($PSStyle.Reset)"

        if ($isLast -and $isInvertedEnd -eq $false) {
            # Write-Host $endSymbolFg$endSymbol$($PSStyle.Reset) -NoNewline
            $output += "$endSymbolFg$endSymbol$($PSStyle.Reset)"
        }
        else {
            # Write-Host $endSymbolBg$endSymbolFg$endSymbol$($PSStyle.Reset) -NoNewline
            $output += "$endSymbolBg$endSymbolFg$endSymbol$($PSStyle.Reset)"
        }
    }

    return $output
}

function Render-Intermediate-Tags {
    param([string]$template, $bg, $fg)

    $output = $template -replace '<transparent>', "<$($terminal.background)>"
    $output = $output -replace '<background>', "<$($terminal.background)>"
    $output = $output -replace '<foreground>', "<$($terminal.foreground)>"
    $output = $output -replace '<b>', "$($PSStyle.Bold)"
    $output = $output -replace '<i>', "$($PSStyle.Italic)"
    $output = $output -replace '<u>', "$($PSStyle.Underline)"
    $output = $output -replace '<s>', "$($PSStyle.Strikethrough)"
    $output = $output -replace '<blink>', "$($PSStyle.Blink)"

    $output = $output -replace '</>', "$($PSStyle.Reset)$bg$fg"

    $output = [regex]::Replace($output, '<#([A-Fa-f0-9]{6})>', {
            param($match)
            $hex = $match.Groups[1].Value
            return HexToRBG $hex
        })

    return $output
}

function HexToRBG {
    param([string]$Hex, [switch]$Background)
    if ($Hex -eq 'transparent' -or $Hex -eq 'background') {
        $Hex = $terminal.background
    }
    elseif ($Hex -eq 'foreground') {
        $Hex = $terminal.foreground
    }
    $Hex = $Hex.Replace("#", "")
    $r = [Convert]::ToInt32($Hex.Substring(0, 2), 16)
    $g = [Convert]::ToInt32($Hex.Substring(2, 2), 16)
    $b = [Convert]::ToInt32($Hex.Substring(4, 2), 16)

    if ($Background) {
        return $PSStyle.Background.FromRgb($r, $g, $b)
    }
    return $PSStyle.Foreground.FromRgb($r, $g, $b)
}

function prompt {
    Initialize-Values
    Initialize-Theme
    return ' '
}

function Initialize-Values {
    $currentPath = $ExecutionContext.SessionState.Path.CurrentLocation.Path

    $Global:values = [PSCustomObject]@{
        Name   = $env:USERNAME
        Host   = $env:COMPUTERNAME
        Path   = $currentPath
        Folder = Split-Path $currentPath -Leaf
    }
}


function Render-Static-Values {
    param ($template)
    $output = $template -replace '\{\{\s*\.UserName\s*\}\}', $Global:values.Name
    $output = $output -replace '\{\{\s*\.HostName\s*\}\}', $Global:values.Host
    return $output
}

function Render-Dynamic-Values {
    param ($template)

    $output = $template -replace '\{\{\s*\.Path\s*\}\}', $Global:values.Path
    $output = $output -replace '\{\{\s*\.Folder\s*\}\}', $Global:values.Folder
    $output = $output -replace '\{\{\s*\.Time\s*\}\}', (Get-Date -Format "HH:mm:ss")

    return $output
}


# timer...
# $timer = [System.Timers.Timer]::new(1000)
# $timer.AutoReset = $true
# $timer.Enabled = $true

# Register-ObjectEvent -InputObject $timer -EventName Elapsed -Action {
#     $time = Get-Date -Format "HH:mm:ss"
#     $host.UI.RawUI.WindowTitle = "Time: $time | User: $env:USERNAME"
# }